<table class="form-table">
    <tr>
        <th>Facebook link</th>
        <td><?php $controls->text('theme_facebook'); ?></td>
    </tr>
    <tr>
        <th>Twitter link</th>
        <td><?php $controls->text('theme_twitter'); ?></td>
    </tr>
    <tr>
        <th>YouTube link</th>
        <td><?php $controls->text('theme_youtube'); ?></td>
    </tr>
</table>