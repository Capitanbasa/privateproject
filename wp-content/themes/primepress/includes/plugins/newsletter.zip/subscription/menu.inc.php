<h5>Subscription Module</h5>
<div id="newsletter-nav">
    <a class="button" href="<?php echo $module->get_admin_page_url('options'); ?>">Subscription and unsubscription</a>
    <a class="button" href="<?php echo $module->get_admin_page_url('profile'); ?>">Form fields and layout</a>
    <a class="button" href="<?php echo $module->get_admin_page_url('forms'); ?>">Alternative forms</a>
</div>