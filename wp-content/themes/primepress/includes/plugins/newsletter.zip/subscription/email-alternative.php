<?php

// TODO: Explain how to customize.

?>
<html>
  <head>
    <style type="text/css">
    </style>
  </head>

  <body style="font-family: sans-serif; font-size: 12px">
      <?php echo $message; ?>
  </body>
</html>