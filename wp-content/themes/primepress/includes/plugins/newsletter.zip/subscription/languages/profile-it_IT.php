<?php

$options = array();
$options['email'] = 'Email';
$options['email_error'] = 'L\'indirizzo email non è corretto';
$options['name'] = 'Nome';
$options['name_error'] = 'Il nome non è corretto';
$options['surname'] = 'Cognome';
$options['surname_error'] = 'Il cognome non è corretto';
$options['sex'] = 'Sono';
$options['privacy'] = 'Accetto le regole di riservatezza di questo sito';
$options['privacy_error'] = 'Devi accettare le regole di riservatezza';
$options['subscribe'] = 'Procedi';
$options['save'] = 'Salva';

